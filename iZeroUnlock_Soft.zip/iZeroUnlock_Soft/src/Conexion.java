
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Edwin_PC
 */
public class Conexion {

    String url = "jdbc:mysql://65.99.252.93:3306/icloudfm_test";
    //String url = "jdbc:mysql://65.99.252.93:3306/icloudfm_test";
    String usuario = "icloudfm_usuario";
    String contraseña = "eDWIN654-@";
    Connection con = null;
    Statement stmt = null;

    public Conexion() {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(url, usuario, contraseña);
            if (con != null) {
                System.out.println("Se ha establecido una conexión a la base de datos "
                        + "\n " + url);
                JOptionPane.showMessageDialog(null, "Se ha establecido una conexión a la base de datos "
                        + "\n "); // + url);
            }
            

            //
            //
            //stmt = (Statement) con.getClientInfo();

            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO usuarios" + "(id, nombre, email, clave, cargo, created) VALUES"
                        + "(?,?,?,?,?, STR_TO_DATE(?,'%Y/%m/%d'))");

                //'5','Victor soto','victorcorrales125@gmail.com','','',''
                System.out.println("Los valores han sido agregados a la base de datos ");
                JOptionPane.showMessageDialog(null, "Los valores han sido agregados a la base de datos ");
                        

        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (con != null) {
                try {
                    con.close();
                    stmt.close();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
        /*
        javax.swing.JOptionPane.showMessageDialog(null, "Registro exitoso! \n", "AVISO!", javax.swing.JOptionPane.INFORMATION_MESSAGE);
         */
    }

}

/*
                stmt.executeUpdate("INSERT INTO usuarios "
                        + "VALUES('" + 0 + "','" + cadena2 + "','" + cadena3 + "','" + cadena4 + "','" + cadena5 + "','" + cadena6 + "'yyyy/dd/MM HH:mm:ss)'");
 */
//'5','Victor soto','victorcorrales125@gmail.com','','',''

